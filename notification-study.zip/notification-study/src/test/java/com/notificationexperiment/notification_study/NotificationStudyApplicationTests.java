package com.notificationexperiment.notification_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
