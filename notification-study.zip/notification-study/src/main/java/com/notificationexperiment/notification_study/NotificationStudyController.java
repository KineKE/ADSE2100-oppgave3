package com.notificationexperiment.notification_study;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api")
public class NotificationStudyController {

    // Liste å lagre deltakerdata
    private List<Map<String, Object>> participantData = new ArrayList<>();

    // Endpoint for å logge data
    @PostMapping("/logData")
    public String logData(@RequestBody Map<String, Object> data) {
        participantData.add(data);
        System.out.println("Data mottatt: " + data);
        return "Data logging gjennomført";
    }

    // Endpoint for å motta data
    @GetMapping("/getData")
    public List<Map<String, Object>> getData() {
        return participantData;
    }
}
