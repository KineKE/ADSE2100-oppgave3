package com.notificationexperiment.notification_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificationStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotificationStudyApplication.class, args);
	}
}
