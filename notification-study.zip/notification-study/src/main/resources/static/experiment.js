// Funksjon for å spille av testlyden
function playTestSound() {
    const audio = document.getElementById("test-sound");
    audio.play();
}

// Håndtere klikk på knapp på første skjerm (samtykke)
document.getElementById("consent-button").addEventListener("click", function() {
    // Skjul velkomstskjermen og vis metadata-skjermen
    document.querySelector(".welcome-screen").style.display = "none";
    document.querySelector(".metadata-screen").style.display = "block";
});

// Håndtere innlevering av skjema for metadata
document.getElementById("participant-form").addEventListener("submit", function(event) {
    event.preventDefault();

    // Samle deltakerinfo og starte eksperimentet
    const age = document.getElementById("age").value;
    const gender = document.getElementById("gender").value;
    const audioOutput = document.getElementById("audio-output").value;
    const inputDevice = document.getElementById("input-device").value;
    const hearingImpairment = document.getElementById("hearing-impairment").value;
    const computerFamiliarity = document.getElementById("computer-familiarity").value;
    const previousStudy = document.getElementById("previous-study").value;


    // Lagre metadata
    const participantData = {
        age,
        gender,
        audioOutput,
        inputDevice,
        hearingImpairment,
        computerFamiliarity,
        previousStudy,
        responseTimes: [] };

    // Skjul velkomstskjerm og vis test-skjerm
    document.querySelector(".metadata-screen").style.display = "none";
    document.querySelector(".experiment-screen").style.display = "block";

    startExperiment(participantData);

})

function startExperiment(participantData) {

    // Vis det som skal leses og sett opp notifikasjoner
    const textContent = document.querySelector(".text-content");
    textContent.innerHTML = "Her kommer tekstinnholdet mitt";

    let notificationCount = 0;
    const maxNotifications = 10;

    function showNotification() {
        if (notificationCount >= maxNotifications) {
            endExperiment(participantData);
            return;
        }

        notificationCount++;
        const withSound = Math.random() > 0.5;
        const notificationStart = Date.now();

        if (withSound) {
            const audio = new Audio("path/to/sound");
            audio.play();
        }

        alert("Klikk OK for å lukke notifikasjon.");

        const responseTime = Date.now() - notificationStart;
        participantData.responseTimes.push({ withSound, responseTime });

        // Schedule neste notifikasjon
        const nextInterval = Math.random() * (6000 - 3000) + 3000; // 30 - 60 sekunder
        setTimeout(showNotification, nextInterval);
    }

    // Start den første notifikasjonen
    setTimeout(showNotification, Math.random() * (6000 - 3000) + 3000);
}

function endExperiment(participantData) {
    // Skjul testskjermen og vis avslutningsskjermen
    document.querySelector(".experiment-screen").style.display = "none";
    document.querySelector(".end-screen").style.display = "block";

    // Send data til backend
    fetch("/api/logData", {
        method: "POST",
        headers: {"Content-type": "application/json" },
        body: JSON.stringify(participantData)
    }).then(response => response.text())
        .then(data => console.log("Data logged:", data))
        .catch(error => console.log("Error:", error));
}